import dev.microblocks.block.MicroVoxels;

import java.util.HashSet;
import java.util.Set;

public class VoxelTest {
    private static int failures = 0;

    private static void check(String name, boolean ok) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + name);
        if (!ok) {
            failures++;
        }
    }

    public static void main(String[] args) {
        // 1. 索引唯一性：4096 个格子必须映射到 4096 个不同下标，且都在 0..4095
        Set<Integer> seen = new HashSet<>();
        boolean inRange = true;
        for (int x = 0; x < 16; x++) {
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    int i = MicroVoxels.index(x, y, z);
                    if (i < 0 || i >= MicroVoxels.COUNT) {
                        inRange = false;
                    }
                    seen.add(i);
                }
            }
        }
        check("4096 个格子下标唯一且不越界", seen.size() == 4096 && inRange);

        // 2. 反解正确
        boolean inverseOk = true;
        for (int i : seen) {
            if (MicroVoxels.index(MicroVoxels.xOf(i), MicroVoxels.yOf(i), MicroVoxels.zOf(i)) != i) {
                inverseOk = false;
                break;
            }
        }
        check("下标可反解回 x/y/z", inverseOk);

        // 3. set/get 往返
        long[] bits = new long[MicroVoxels.LONG_COUNT];
        MicroVoxels.set(bits, 3, 7, 11, true);
        MicroVoxels.set(bits, 15, 15, 15, true);
        MicroVoxels.set(bits, 0, 0, 0, true);
        check("点位写入可读回", MicroVoxels.get(bits, 3, 7, 11)
                && MicroVoxels.get(bits, 15, 15, 15)
                && MicroVoxels.get(bits, 0, 0, 0));

        MicroVoxels.set(bits, 3, 7, 11, false);
        check("擦除后读为 false", !MicroVoxels.get(bits, 3, 7, 11));
        check("擦除不影响相邻格", MicroVoxels.get(bits, 15, 15, 15));

        // 4. 计数（此时 3 个点位里已擦掉 1 个，剩 2 个）
        check("擦除 1 个后 count=2", MicroVoxels.count(bits) == 2);
        MicroVoxels.fill(bits);
        check("fill 后 count=4096", MicroVoxels.count(bits) == 4096);
        check("fill 后不认为空", !MicroVoxels.isEmpty(bits));
        MicroVoxels.clear(bits);
        check("clear 后 count=0", MicroVoxels.count(bits) == 0);
        check("clear 后 isEmpty", MicroVoxels.isEmpty(bits));

        // 5. 命中点换算：0.0 落在第 0 格，0.999 落在第 15 格，边界不越界
        check("local 0.0 -> 0", MicroVoxels.fromLocal(0.0) == 0);
        check("local 0.999 -> 15", MicroVoxels.fromLocal(0.999) == 15);
        check("local 1.0 夹到 15", MicroVoxels.fromLocal(1.0) == 15);
        check("local 负数夹到 0", MicroVoxels.fromLocal(-0.5) == 0);

        System.out.println(failures == 0 ? "\nALL OK" : "\n" + failures + " FAILURE(S)");
        if (failures != 0) {
            System.exit(1);
        }
    }
}
