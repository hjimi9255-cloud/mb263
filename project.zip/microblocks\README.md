# Micro Blocks（微方块）

一个给自己用的「LittleTiles 简化版」：把 1 个方块空间切成 16×16×16 = 4096 个微格，用凿子凿掉、补回，材质继承被凿的方块。

> 说明：这份代码是**逻辑完整、但没经过本机编译验证**的工程。原因写在文末「为什么没在这台机器上编译」。
> 预期需要改的地方已经用 `[26.3?]` 标在代码里，共 5 处，见下面「首次构建必改清单」。

---

## 1. 功能

| 操作 | 结果 |
| --- | --- |
| 用凿子右键**普通方块** | 该方块被替换成微方块，内部塞满 16³，外观材质继承原方块 |
| 用凿子右键**微方块** | 凿掉准心命中的那一个 1/16 小方块 |
| **Shift + 右键** 微方块 | 把命中的空微格补回 1/16 |

数据模型：每个方块的 `long[64]` 位图（4096 bit），越界坐标自动夹取，渲染时剔除相邻面。

## 2. 目录结构

```
microblocks/
├─ build.gradle                  Loom 构建脚本
├─ settings.gradle               插件仓库 + foojay（自动下 JDK 25）
├─ gradle.properties             ← 版本号都在这里
├─ .github/workflows/build.yml   GitHub Actions 一键出 jar
└─ src/main/
   ├─ java/dev/microblocks/
   │  ├─ MicroBlocks.java              注册方块/物品/方块实体
   │  ├─ block/MicroVoxels.java         16³ 位图（纯逻辑，无 MC 依赖，可单独测）
   │  ├─ block/MicroBlock.java          方块本体（不渲染，交给 BE）
   │  ├─ block/MicroBlockEntity.java    数据 + NBT + 碰撞箱缓存
   │  ├─ item/ChiselItem.java           凿子交互逻辑
   │  └─ client/MicroBlockRenderer.java 逐微格画实体面（带剔除）
   └─ resources/
      ├─ fabric.mod.json
      └─ assets/microblocks/…           方块状态/模型/语言文件
```

## 3. 三步出 jar（推荐，不用装 JDK 和 Gradle）

1. 在 GitHub 新建一个空仓库（private 也行）。
2. 把整个 `microblocks` 文件夹的内容推上去（`git init && git add . && git commit -m init && git push`）。
3. 打开仓库的 **Actions** 页 → 点 `build` → Run workflow。跑完在页面的 **Artifacts** 里下载 `microblocks-jar`，解压得到 `microblocks-0.1.0.jar`。

把 jar 丢进：

```
C:\Users\bu\Desktop\.minecraft\versions\26.3-Fabric 0.20.1\mods
```

## 4. 本地构建（如果你有 JDK 25 + Gradle）

```bash
cd microblocks
gradle build      # 或者 gradle wrapper 之后 .\gradlew build
```

产物在 `build/libs/`。注意本机缺 Loom/映射，不建议在没网的地方硬跑。

## 5. 首次构建必改清单（5 处）

| # | 位置 | 会报什么 | 怎么改 |
| --- | --- | --- | --- |
| 1 | `gradle.properties` → `yarn_mappings` | 依赖解析失败 / 找不到 26.3+build.1 | 打开 <https://fabricmc.net/develop>，把 26.3 对应的 yarn 版本抄过来 |
| 2 | `loom_version` | 插件版本不存在 | 同一页面用最新稳定 Loom |
| 3 | `MicroBlockEntity` 的 `nbt.getLongArray / getString` | `Optional<long[]>` / `Optional<String>` 类型不匹配 | 加 `.orElse(...)`，见代码注释 |
| 4 | `MicroBlockRenderer.render(...)` | 参数个数对不上 | 新版可能多一个 `Vec3d cameraPos` 之类，按 IDE 提示补 |
| 5 | `MicroBlockRenderer` 的 `RenderLayer.getSolid()` | 编译过但进游戏是纯黑/无纹理 | 换成 `POSITION_COLOR` 顶点格式的自定义 RenderLayer（见下） |

第 5 项的参考写法（如果纯色块画不出来，把 `getBuffer(...)` 换成这个）：

```java
// 在 MicroBlockRenderer 里加一个静态字段
private static final RenderLayer LAYER = RenderLayer.of(
        "microblocks_solid",
        VertexFormats.POSITION_COLOR,
        1536,
        false,
        false,
        RenderLayer.MultiPhaseParameters.builder()
                .program(RenderLayer.COLOR_PROGRAM)
                .build(false));
```

`RenderLayer.COLOR_PROGRAM` / `MultiPhaseParameters` 这套在 1.21 后期到 26.x 之间改过，按报错改成当前版本的对应常量。

## 6. 玩法

进游戏后先拿凿子：

```
/give @s microblocks:chisel
```

- 拿凿子右键石头 → 石头变成整块满格的微方块；
- 继续右键它 → 一小块一小块凿掉（可以凿出任意的凹凸、台阶、柱子）；
- Shift + 右键 → 补回来。

凿出来的微方块**不受方块朝向限制**，因为每个 1/16 格子是独立占用的，这跟 LittleTiles 的核心玩法一致。

## 7. 已知没做的（要自己加）

- **纯色渲染**：没有纹理采样，颜色取方块地图色。想要贴图得在 BE 里存方块状态并用 `SpriteAtlas` 取 UV。
- **没有存档同步优化**：每次凿一格都 `updateListeners`，量大时会有点吵。
- **没有配方 / 创造模式标签页**：目前只能 `/give`。
- **性能**：单方块最多 4096 格，极端情况一区块几万个面。要正经用得加「按区块合并 Mesh + 面剔除缓存」。
- **碰撞箱退化**：占用超过 256 格时直接用整块碰撞（省性能，但手感会变「方」）。

## 8. 为什么没在这台机器上编译

- Fabric 的构建必需品（Loom 插件、yarn 映射、Fabric Loader）只发布在 `maven.fabricmc.net`，本机访问该域名 **30 秒超时**；
- 阿里云 / 华为云 / 腾讯云三个国内 Maven 镜像都不代理 Fabric 的构件（实测 404）；
- 本机 JDK 只有 Java 8，但 PCL 自带 `java-runtime-epsilon` 是完整 JDK 25（这个反而没问题）。

也就是说：**能写、能在这台机器上做语法与逻辑验证，但无法把 jar 编出来**。所以走 GitHub Actions 这条路最稳。
