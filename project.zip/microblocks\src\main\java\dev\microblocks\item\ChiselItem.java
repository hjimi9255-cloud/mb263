package dev.microblocks.item;

import dev.microblocks.MicroBlocks;
import dev.microblocks.block.MicroBlock;
import dev.microblocks.block.MicroBlockEntity;
import dev.microblocks.block.MicroVoxels;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * 凿子：
 *  - 右键普通方块  → 整个方块变成微方块（塞满 16³，材质继承原方块）
 *  - 右键微方块    → 凿掉准心命中的那一个 1/16 小方块
 *  - Shift + 右键  → 把命中的那个 1/16 小方块补回来
 */
public class ChiselItem extends Item {
    public ChiselItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos();
        BlockState state = world.getBlockState(pos);
        PlayerEntity player = context.getPlayer();
        Vec3d hit = context.getHitPos();

        // ---- 情况一：命中的已经是微方块 ----
        if (world.getBlockEntity(pos) instanceof MicroBlockEntity micro) {
            int vx = MicroVoxels.fromLocal(hit.x - pos.getX());
            int vy = MicroVoxels.fromLocal(hit.y - pos.getY());
            int vz = MicroVoxels.fromLocal(hit.z - pos.getZ());

            boolean occupied = MicroVoxels.get(micro.getBits(), vx, vy, vz);
            boolean restore = player != null && player.isSneaking();

            if (restore) {
                if (occupied) {
                    return ActionResult.PASS;
                }
                micro.setVoxel(vx, vy, vz, true);
            } else {
                if (!occupied) {
                    return ActionResult.PASS;
                }
                micro.setVoxel(vx, vy, vz, false);
            }

            sync(world, pos, state);
            if (player != null) {
                player.swingHand(context.getHand());
            }
            return ActionResult.SUCCESS;
        }

        // ---- 情况二：把普通方块凿成微方块 ----
        if (state.isAir() || state.getBlock() instanceof MicroBlock) {
            return ActionResult.PASS;
        }
        // 基岩、命令方块这类打不掉的方块不转换
        if (state.getHardness(world, pos) < 0.0F) {
            return ActionResult.PASS;
        }

        if (world.isClient) {
            return ActionResult.SUCCESS;
        }

        world.setBlockState(pos, MicroBlocks.MICRO_BLOCK.getDefaultState());
        if (world.getBlockEntity(pos) instanceof MicroBlockEntity created) {
            created.setMaterial(state);
            created.fillFull();
        }
        if (player != null) {
            player.swingHand(context.getHand());
        }
        return ActionResult.SUCCESS;
    }

    private static void sync(World world, BlockPos pos, BlockState state) {
        if (world.isClient) {
            return;
        }
        world.updateListeners(pos, state, state, Block.NOTIFY_ALL);
        world.markDirty(pos);
    }
}
