package dev.microblocks.client;

import dev.microblocks.MicroBlocks;
import dev.microblocks.block.MicroBlockEntity;
import dev.microblocks.block.MicroVoxels;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

/**
 * 把 16³ 位图里的每个 1/16 立方体画成一个面片组，邻居占用的面直接剔除。
 * 颜色取材质方块的地图色（没有纹理采样，所以看起来是纯色实心块）。
 */
public class MicroBlockRenderer implements BlockEntityRenderer<MicroBlockEntity> {
    private static final float V = 1.0F / MicroVoxels.SIZE;

    public MicroBlockRenderer(BlockEntityRendererFactory.Context context) {
    }

    // [26.3?] 若方法签名对不上（新版可能多一个 Vec3d cameraPos 参数），按 IDE 提示补参数即可
    @Override
    public void render(MicroBlockEntity entity, float tickProgress, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light, int overlay) {
        if (entity.isEmpty()) {
            return;
        }

        BlockState material = entity.getMaterial();
        int rgb = colorOf(material);
        int r = (rgb >> 16) & 0xFF;
        int g = (rgb >> 8) & 0xFF;
        int b = rgb & 0xFF;

        // [26.3?] 若渲染成纯黑/无纹理，把 getSolid() 换成带 POSITION_COLOR 的图层（见 README）
        VertexConsumer buffer = vertexConsumers.getBuffer(RenderLayer.getSolid());
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        long[] bits = entity.getBits();

        for (int x = 0; x < MicroVoxels.SIZE; x++) {
            for (int y = 0; y < MicroVoxels.SIZE; y++) {
                for (int z = 0; z < MicroVoxels.SIZE; z++) {
                    if (!MicroVoxels.get(bits, x, y, z)) {
                        continue;
                    }
                    float x0 = x * V;
                    float y0 = y * V;
                    float z0 = z * V;
                    float x1 = x0 + V;
                    float y1 = y0 + V;
                    float z1 = z0 + V;

                    if (y == 0 || !MicroVoxels.get(bits, x, y - 1, z)) {
                        down(buffer, matrix, x0, y0, z0, x1, y1, z1, r, g, b, light);
                    }
                    if (y == MicroVoxels.SIZE - 1 || !MicroVoxels.get(bits, x, y + 1, z)) {
                        up(buffer, matrix, x0, y0, z0, x1, y1, z1, r, g, b, light);
                    }
                    if (x == 0 || !MicroVoxels.get(bits, x - 1, y, z)) {
                        west(buffer, matrix, x0, y0, z0, x1, y1, z1, r, g, b, light);
                    }
                    if (x == MicroVoxels.SIZE - 1 || !MicroVoxels.get(bits, x + 1, y, z)) {
                        east(buffer, matrix, x0, y0, z0, x1, y1, z1, r, g, b, light);
                    }
                    if (z == 0 || !MicroVoxels.get(bits, x, y, z - 1)) {
                        north(buffer, matrix, x0, y0, z0, x1, y1, z1, r, g, b, light);
                    }
                    if (z == MicroVoxels.SIZE - 1 || !MicroVoxels.get(bits, x, y, z + 1)) {
                        south(buffer, matrix, x0, y0, z0, x1, y1, z1, r, g, b, light);
                    }
                }
            }
        }
    }

    private static int colorOf(BlockState state) {
        try {
            // [26.3?] 若签名变了，改成 state.getBlock().getDefaultMapColor().color 之类的写法
            return state.getMapColor(null, null).color;
        } catch (Throwable ignored) {
            return 0x9E9E9E;
        }
    }

    private static void vertex(VertexConsumer buf, Matrix4f m, float x, float y, float z,
                               int r, int g, int b, int light, float nx, float ny, float nz) {
        buf.vertex(m, x, y, z).color(r, g, b, 255).texture(0.0F, 0.0F).light(light).normal(nx, ny, nz);
    }

    private static void down(VertexConsumer buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1,
                             int r, int g, int b, int light) {
        vertex(buf, m, x0, y0, z1, r, g, b, light, 0, -1, 0);
        vertex(buf, m, x1, y0, z1, r, g, b, light, 0, -1, 0);
        vertex(buf, m, x1, y0, z0, r, g, b, light, 0, -1, 0);
        vertex(buf, m, x0, y0, z0, r, g, b, light, 0, -1, 0);
    }

    private static void up(VertexConsumer buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1,
                           int r, int g, int b, int light) {
        vertex(buf, m, x0, y1, z0, r, g, b, light, 0, 1, 0);
        vertex(buf, m, x1, y1, z0, r, g, b, light, 0, 1, 0);
        vertex(buf, m, x1, y1, z1, r, g, b, light, 0, 1, 0);
        vertex(buf, m, x0, y1, z1, r, g, b, light, 0, 1, 0);
    }

    private static void north(VertexConsumer buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1,
                              int r, int g, int b, int light) {
        vertex(buf, m, x0, y0, z0, r, g, b, light, 0, 0, -1);
        vertex(buf, m, x1, y0, z0, r, g, b, light, 0, 0, -1);
        vertex(buf, m, x1, y1, z0, r, g, b, light, 0, 0, -1);
        vertex(buf, m, x0, y1, z0, r, g, b, light, 0, 0, -1);
    }

    private static void south(VertexConsumer buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1,
                              int r, int g, int b, int light) {
        vertex(buf, m, x1, y0, z1, r, g, b, light, 0, 0, 1);
        vertex(buf, m, x0, y0, z1, r, g, b, light, 0, 0, 1);
        vertex(buf, m, x0, y1, z1, r, g, b, light, 0, 0, 1);
        vertex(buf, m, x1, y1, z1, r, g, b, light, 0, 0, 1);
    }

    private static void west(VertexConsumer buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1,
                             int r, int g, int b, int light) {
        vertex(buf, m, x0, y0, z1, r, g, b, light, -1, 0, 0);
        vertex(buf, m, x0, y0, z0, r, g, b, light, -1, 0, 0);
        vertex(buf, m, x0, y1, z0, r, g, b, light, -1, 0, 0);
        vertex(buf, m, x0, y1, z1, r, g, b, light, -1, 0, 0);
    }

    private static void east(VertexConsumer buf, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1,
                             int r, int g, int b, int light) {
        vertex(buf, m, x1, y0, z0, r, g, b, light, 1, 0, 0);
        vertex(buf, m, x1, y0, z1, r, g, b, light, 1, 0, 0);
        vertex(buf, m, x1, y1, z1, r, g, b, light, 1, 0, 0);
        vertex(buf, m, x1, y1, z0, r, g, b, light, 1, 0, 0);
    }
}
