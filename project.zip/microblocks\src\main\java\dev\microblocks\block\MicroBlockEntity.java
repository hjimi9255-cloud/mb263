package dev.microblocks.block;

import dev.microblocks.MicroBlocks;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;

/**
 * 一个方块位置里存 16³ 的占用位图 + 一个「材质」（用哪种方块的外观）。
 * 数据全部落在方块实体里，所以方块本身可以是空的、不可见。
 */
public class MicroBlockEntity extends BlockEntity {
    public static final String KEY_BITS = "Bits";
    public static final String KEY_MATERIAL = "Material";

    private final long[] bits = new long[MicroVoxels.LONG_COUNT];
    private BlockState material = Blocks.STONE.getDefaultState();

    private VoxelShape cachedShape;
    private boolean shapeDirty = true;

    public MicroBlockEntity(BlockPos pos, BlockState state) {
        super(MicroBlocks.MICRO_BLOCK_ENTITY, pos, state);
    }

    // ---------------------------------------------------------------- 数据

    public long[] getBits() {
        return bits;
    }

    public BlockState getMaterial() {
        return material;
    }

    public void setMaterial(BlockState state) {
        this.material = state;
        markDirty();
    }

    public void fillFull() {
        MicroVoxels.fill(bits);
        invalidateShape();
        markDirty();
    }

    public boolean setVoxel(int x, int y, int z, boolean occupied) {
        boolean before = MicroVoxels.get(bits, x, y, z);
        if (before == occupied) {
            return false;
        }
        MicroVoxels.set(bits, x, y, z, occupied);
        invalidateShape();
        markDirty();
        return true;
    }

    public boolean isEmpty() {
        return MicroVoxels.isEmpty(bits);
    }

    private void invalidateShape() {
        shapeDirty = true;
    }

    // ---------------------------------------------------------------- 碰撞箱

    /**
     * 碰撞/描边形状。为了不让每次碰撞都遍历 4096 格，这里做了缓存；
     * 而且格子太碎（>256 个）时直接退化成整块，避免 union 出上千个 box 拖死服务器。
     */
    public VoxelShape getShape() {
        if (!shapeDirty && cachedShape != null) {
            return cachedShape;
        }
        int count = MicroVoxels.count(bits);
        if (count == 0) {
            cachedShape = VoxelShapes.empty();
        } else if (count > 256) {
            cachedShape = VoxelShapes.fullCube();
        } else {
            VoxelShape shape = VoxelShapes.empty();
            for (int x = 0; x < MicroVoxels.SIZE; x++) {
                for (int y = 0; y < MicroVoxels.SIZE; y++) {
                    for (int z = 0; z < MicroVoxels.SIZE; z++) {
                        if (!MicroVoxels.get(bits, x, y, z)) {
                            continue;
                        }
                        shape = VoxelShapes.union(shape, VoxelShapes.cuboid(
                                x / 16.0, y / 16.0, z / 16.0,
                                (x + 1) / 16.0, (y + 1) / 16.0, (z + 1) / 16.0));
                    }
                }
            }
            cachedShape = shape;
        }
        shapeDirty = false;
        return cachedShape;
    }

    // ---------------------------------------------------------------- 存档

    @Override
    protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.writeNbt(nbt, registries);
        nbt.putLongArray(KEY_BITS, bits);
        nbt.putString(KEY_MATERIAL, Registries.BLOCK.getId(material.getBlock()).toString());
    }

    @Override
    protected void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.readNbt(nbt, registries);

        // [26.3?] 若编译报“Optional<long[]>”，改成 nbt.getLongArray(KEY_BITS).orElse(new long[0])
        long[] stored = nbt.getLongArray(KEY_BITS);
        if (stored != null && stored.length == bits.length) {
            System.arraycopy(stored, 0, bits, 0, bits.length);
        }

        // [26.3?] 同理，getString 若返回 Optional<String>，用 nbt.getString(KEY_MATERIAL).orElse("")
        Identifier materialId = Identifier.tryParse(nbt.getString(KEY_MATERIAL));
        if (materialId != null && Registries.BLOCK.containsId(materialId)) {
            material = Registries.BLOCK.get(materialId).getDefaultState();
        }
        invalidateShape();
    }
}
