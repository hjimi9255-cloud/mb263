package dev.microblocks.block;

import java.util.Arrays;

/**
 * 一个方块空间被切成 16×16×16 = 4096 个「微格」，用 64 个 long 位图存占用状态。
 * 这个类不依赖任何 Minecraft 类型，可以单独编译测试。
 */
public final class MicroVoxels {
    /** 每个轴向的格数 */
    public static final int SIZE = 16;
    /** 格子总数 */
    public static final int COUNT = SIZE * SIZE * SIZE;
    /** 需要的 long 个数（4096 / 64） */
    public static final int LONG_COUNT = COUNT / 64;

    private MicroVoxels() {
    }

    /** x,y,z 必须是 0..15；打包成 12 bit 的线性下标，顺序与渲染顺序一致 */
    public static int index(int x, int y, int z) {
        return (x << 8) | (y << 4) | z;
    }

    public static int xOf(int index) {
        return (index >> 8) & 0xF;
    }

    public static int yOf(int index) {
        return (index >> 4) & 0xF;
    }

    public static int zOf(int index) {
        return index & 0xF;
    }

    public static boolean get(long[] bits, int x, int y, int z) {
        int i = index(x, y, z);
        return (bits[i >>> 6] & (1L << (i & 63))) != 0L;
    }

    public static void set(long[] bits, int x, int y, int z, boolean value) {
        int i = index(x, y, z);
        long mask = 1L << (i & 63);
        if (value) {
            bits[i >>> 6] |= mask;
        } else {
            bits[i >>> 6] &= ~mask;
        }
    }

    /** 已占用的格子数量 */
    public static int count(long[] bits) {
        int n = 0;
        for (long word : bits) {
            n += Long.bitCount(word);
        }
        return n;
    }

    public static boolean isEmpty(long[] bits) {
        for (long word : bits) {
            if (word != 0L) {
                return false;
            }
        }
        return true;
    }

    public static void clear(long[] bits) {
        Arrays.fill(bits, 0L);
    }

    /** 整块塞满（17 个 1/16 立方体的那种满格） */
    public static void fill(long[] bits) {
        Arrays.fill(bits, -1L);
    }

    /** 越界或非法输入一律夹回 0..15，避免拿命中点算格子时崩 */
    public static int clamp(int v) {
        if (v < 0) {
            return 0;
        }
        return v > SIZE - 1 ? SIZE - 1 : v;
    }

    /** 从世界坐标的命中点算出微格坐标：把 0..1 的局部坐标乘 16 再取整 */
    public static int fromLocal(double local) {
        int v = (int) Math.floor(local * SIZE);
        return clamp(v);
    }
}
