#!/usr/bin/env bash
# 在 GitHub Actions 的 Ubuntu runner 上跑：自动查真实版本号 -> 改 gradle.properties -> 编译
# 本地无法运行（本机到 fabric 官方 maven 不通），只在 CI 里用。

HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1
echo "== working dir: $HERE"
echo "== rank: $(uname -a)"

echo ""
echo "== 1) fetch versions from fabric maven =="
curl -fsS --max-time 30 https://maven.fabricmc.net/net/fabricmc/yarn/maven-metadata.xml -o /tmp/yarn.xml \
  && echo "yarn metadata OK" || echo "yarn metadata FAIL"

if [ -s /tmp/yarn.xml ]; then
  echo "-- yarn versions matching 26.3 (last 6) --"
  grep -o '<version>[^<]*</version>' /tmp/yarn.xml | sed 's/<[^>]*>//g' | grep '^26\.3' | tail -6
  YARN=$(grep -o '<version>[^<]*</version>' /tmp/yarn.xml | sed 's/<[^>]*>//g' | grep '^26\.3' | tail -1)
  if [ -n "$YARN" ]; then
    echo "picked yarn_mappings=$YARN"
    sed -i "s#^yarn_mappings=.*#yarn_mappings=$YARN#" gradle.properties
  fi
fi

curl -fsS --max-time 30 https://maven.fabricmc.net/net/fabricmc/fabric-loom/maven-metadata.xml -o /tmp/loom.xml \
  && echo "loom metadata OK" || echo "loom metadata FAIL"

if [ -s /tmp/loom.xml ]; then
  echo "-- loom versions (last 8) --"
  grep -o '<version>[^<]*</version>' /tmp/loom.xml | sed 's/<[^>]*>//g' | tail -8
  LOOM=$(grep -o '<version>[^<]*</version>' /tmp/loom.xml | sed 's/<[^>]*>//g' | grep -v SNAPSHOT | tail -1)
  if [ -n "$LOOM" ]; then
    echo "picked loom_version=$LOOM"
    sed -i "s#^loom_version=.*#loom_version=$LOOM#" gradle.properties
  fi
fi

echo ""
echo "== 2) gradle.properties now =="
cat gradle.properties

echo ""
echo "== 3) gradle =="
GV=$(curl -fsS --max-time 20 https://services.gradle.org/versions/current | grep -o '"version"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
[ -z "$GV" ] && GV=9.1.0
echo "gradle version to use: $GV"
if [ ! -x "/tmp/gradle-$GV/bin/gradle" ]; then
  curl -fsSL --max-time 180 "https://services.gradle.org/distributions/gradle-$GV-bin.zip" -o /tmp/g.zip || { echo "gradle download FAIL"; exit 1; }
  unzip -q -o /tmp/g.zip -d /tmp || exit 1
fi
"/tmp/gradle-$GV/bin/gradle" --version || exit 1

echo ""
echo "== 4) build =="
set -o pipefail
"/tmp/gradle-$GV/bin/gradle" build --no-daemon --stacktrace 2>&1 | tail -150
RC=${PIPESTATUS[0]}

echo ""
echo "== 5) result =="
echo "gradle exit code: $RC"
ls -la build/libs 2>/dev/null || echo "no build/libs"
exit $RC
