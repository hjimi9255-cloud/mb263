package dev.microblocks;

import dev.microblocks.block.MicroBlock;
import dev.microblocks.block.MicroBlockEntity;
import dev.microblocks.item.ChiselItem;
import net.fabricmc.api.ModInitializer;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MicroBlocks implements ModInitializer {
    public static final String MOD_ID = "microblocks";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Block MICRO_BLOCK;
    public static Item CHISEL;
    public static BlockEntityType<MicroBlockEntity> MICRO_BLOCK_ENTITY;

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        MICRO_BLOCK = Registry.register(
                Registries.BLOCK,
                id("micro_block"),
                new MicroBlock(AbstractBlock.Settings.create()
                        .strength(0.1f)
                        .nonOpaque())
        );

        // [26.3?] 老版本是 .build(null)，1.21 之后是 .build()
        MICRO_BLOCK_ENTITY = Registry.register(
                Registries.BLOCK_ENTITY_TYPE,
                id("micro_block"),
                BlockEntityType.Builder.create(MicroBlockEntity::new, MICRO_BLOCK).build()
        );

        CHISEL = Registry.register(
                Registries.ITEM,
                id("chisel"),
                new ChiselItem(new Item.Settings().maxCount(1))
        );

        LOGGER.info("Micro Blocks 已加载：方块={} 物品={}", MICRO_BLOCK, CHISEL);
    }
}
