package dev.microblocks.client;

import dev.microblocks.MicroBlocks;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;

@Environment(EnvType.CLIENT)
public class MicroBlocksClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockEntityRendererRegistry.register(MicroBlocks.MICRO_BLOCK_ENTITY, MicroBlockRenderer::new);
    }
}
